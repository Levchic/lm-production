LM Pulse — тремоло
Бесплатный плагин для Logic Pro и других DAW · L.M.Production · lm-production.ru

Ритмичная пульсация громкости. Десять форм волны, синхронизация с темпом проекта (от 1/1 до 1/32) или свободная частота, глубина и баланс исходного и обработанного сигнала.

Форматы: Audio Unit (Logic Pro, GarageBand, MainStage) и VST3 (Reaper, Cubase,
Ableton Live и др.). macOS 11 и новее, Apple Silicon и Intel.

Установка
  1. Дважды щёлкните файл LM-Pulse-1.0.0-macOS.pkg.
  2. Если macOS сообщит, что не может проверить разработчика:
     откройте «Системные настройки → Конфиденциальность и безопасность»,
     внизу нажмите «Всё равно открыть» и запустите установщик ещё раз.
     (Плагин бесплатный и не подписан платным сертификатом Apple —
     это единственная причина предупреждения.)
  3. Установщик положит плагин в /Library/Audio/Plug-Ins.
  4. Перезапустите Logic Pro. Плагин — в списке эффектов:
     Audio Units → L.M.Production → LM Pulse.

Удаление
  Удалите файлы LM Pulse.component из /Library/Audio/Plug-Ins/Components
  и LM Pulse.vst3 из /Library/Audio/Plug-Ins/VST3.

Нашли ошибку или нужен плагин под вашу задачу — напишите:
  Telegram @levlvovich2000 · lev.maidenko@gmail.com
