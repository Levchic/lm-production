LM Orbit — автопанорама
Бесплатный плагин для Logic Pro и других DAW · L.M.Production · lm-production.ru

Звук движется по стереобазе. Десять форм волны, направление (слева направо, справа налево, туда-обратно), ширина, смещение центра, сглаживание, синхронизация с темпом проекта или свободная частота, баланс.

Форматы: Audio Unit (Logic Pro, GarageBand, MainStage) и VST3 (Reaper, Cubase,
Ableton Live и др.). macOS 11 и новее, Apple Silicon и Intel.

Установка
  1. Дважды щёлкните файл LM-Orbit-1.0.0-macOS.pkg.
  2. Если macOS сообщит, что не может проверить разработчика:
     откройте «Системные настройки → Конфиденциальность и безопасность»,
     внизу нажмите «Всё равно открыть» и запустите установщик ещё раз.
     (Плагин бесплатный и не подписан платным сертификатом Apple —
     это единственная причина предупреждения.)
  3. Установщик положит плагин в /Library/Audio/Plug-Ins.
  4. Перезапустите Logic Pro. Плагин — в списке эффектов:
     Audio Units → L.M.Production → LM Orbit.

Удаление
  Удалите файлы LM Orbit.component из /Library/Audio/Plug-Ins/Components
  и LM Orbit.vst3 из /Library/Audio/Plug-Ins/VST3.

Нашли ошибку или нужен плагин под вашу задачу — напишите:
  Telegram @levlvovich2000 · lev.maidenko@gmail.com
